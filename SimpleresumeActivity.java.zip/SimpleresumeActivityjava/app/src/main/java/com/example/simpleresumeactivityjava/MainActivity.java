package com.example.simpleresumeactivityjava;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    ImageView profileImageView;
    Uri profileImageUri;

    EditText nameInput, emailInput, phoneInput, linkedinInput, githubInput, objectiveInput, educationInput, skillsInput, projectsInput, experienceInput;
    Button buildResumeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        profileImageView = findViewById(R.id.profileImageView);

        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        phoneInput = findViewById(R.id.phoneInput);
        linkedinInput = findViewById(R.id.linkedinInput);
        githubInput = findViewById(R.id.githubInput);
        objectiveInput = findViewById(R.id.objectiveInput);
        educationInput = findViewById(R.id.educationInput);
        skillsInput = findViewById(R.id.skillsInput);
        projectsInput = findViewById(R.id.projectsInput);
        experienceInput = findViewById(R.id.experienceInput);
        buildResumeBtn = findViewById(R.id.buildResumeBtn);

        profileImageView.setOnClickListener(v -> openImageChooser());

        buildResumeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ResumeActivity.class);

            intent.putExtra("profileImageUri", profileImageUri != null ? profileImageUri.toString() : null);
            intent.putExtra("name", nameInput.getText().toString());
            intent.putExtra("email", emailInput.getText().toString());
            intent.putExtra("phone", phoneInput.getText().toString());
            intent.putExtra("linkedin", linkedinInput.getText().toString());
            intent.putExtra("github", githubInput.getText().toString());
            intent.putExtra("objective", objectiveInput.getText().toString());
            intent.putExtra("education", educationInput.getText().toString());
            intent.putExtra("skills", skillsInput.getText().toString());
            intent.putExtra("projects", projectsInput.getText().toString());
            intent.putExtra("experience", experienceInput.getText().toString());

            startActivity(intent);
        });
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Profile Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            profileImageUri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), profileImageUri);
                profileImageView.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
