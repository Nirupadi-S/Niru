package com.example.simpleresumeactivityjava;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.LinkMovementMethod;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ResumeActivity extends AppCompatActivity {

    ImageView profileImageView;
    TextView nameView, emailView, phoneView, linkedinView, githubView, objectiveView, educationView, skillsView, projectsView, experienceView;
    Button exportPdfBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resume);

        profileImageView = findViewById(R.id.profileImageView);
        nameView = findViewById(R.id.nameView);
        emailView = findViewById(R.id.emailView);
        phoneView = findViewById(R.id.phoneView);
        linkedinView = findViewById(R.id.linkedinView);
        githubView = findViewById(R.id.githubView);
        objectiveView = findViewById(R.id.objectiveView);
        educationView = findViewById(R.id.educationView);
        skillsView = findViewById(R.id.skillsView);
        projectsView = findViewById(R.id.projectsView);
        experienceView = findViewById(R.id.experienceView);
        exportPdfBtn = findViewById(R.id.exportPdfBtn);

        // Load profile image if available
        String profileImageUriStr = getIntent().getStringExtra("profileImageUri");
        if (profileImageUriStr != null) {
            Uri profileUri = Uri.parse(profileImageUriStr);
            profileImageView.setImageURI(profileUri);
        } else {
            profileImageView.setImageResource(R.drawable.ic_person); // fallback icon
        }

        nameView.setText(getIntent().getStringExtra("name"));
        emailView.setText(getIntent().getStringExtra("email"));
        phoneView.setText(getIntent().getStringExtra("phone"));

        // LinkedIn and GitHub clickable links
        String linkedin = getIntent().getStringExtra("linkedin");
        linkedinView.setText(linkedin != null && !linkedin.isEmpty() ? linkedin : "Not Provided");
        linkedinView.setMovementMethod(LinkMovementMethod.getInstance());

        String github = getIntent().getStringExtra("github");
        githubView.setText(github != null && !github.isEmpty() ? github : "Not Provided");
        githubView.setMovementMethod(LinkMovementMethod.getInstance());

        objectiveView.setText(getIntent().getStringExtra("objective"));
        educationView.setText(getIntent().getStringExtra("education"));
        skillsView.setText(getIntent().getStringExtra("skills"));
        projectsView.setText(getIntent().getStringExtra("projects"));
        experienceView.setText(getIntent().getStringExtra("experience"));

        exportPdfBtn.setOnClickListener(v -> exportResumeToPDF());
    }

    private void exportResumeToPDF() {
        // Create bitmap of the whole layout
        LinearLayout resumeLayout = findViewById(R.id.rootLayout);
        Bitmap bitmap = Bitmap.createBitmap(resumeLayout.getWidth(), resumeLayout.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        resumeLayout.draw(canvas);

        // Create a PdfDocument
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas pdfCanvas = page.getCanvas();
        pdfCanvas.drawBitmap(bitmap, 0, 0, null);
        document.finishPage(page);

        // Save to file
        String directoryPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/";
        String filePath = directoryPath + "resume_" + System.currentTimeMillis() + ".pdf";

        File file = new File(filePath);
        try {
            document.writeTo(new FileOutputStream(file));
            Toast.makeText(this, "PDF saved to " + filePath, Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        document.close();
    }
}
